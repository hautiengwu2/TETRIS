function [CARDc, reconHARM, IF, tfrsq1, tfrsqtic1, tfr1, tfrtic1]...
    = estPPGHarm1(xSHIFT, fs, IHR, hop)

wlen = round(10*fs)*2+1 ; % 20s window
[tfr1, tfrtic1, tfrsq1, ~, tfrsqtic1, ~] = ConceFT_sqSTFT_C(xSHIFT,...
    0, 0.1, 1e-4, hop, wlen, 1, 6, 1, 1, 0) ;

Q = tfrsq1 ;
tmpM = min(3, quantile(IHR, .99)) ;
tmpM = ceil(1.1* tmpM./ ((tfrsqtic1(2) - tfrsqtic1(1))*fs)) ;
tmpm = ceil(0.9* quantile(IHR, .05) ./ ((tfrsqtic1(2) - tfrsqtic1(1))*fs)) ;
Q(1:tmpm, :) = 0 ;


% get the fundamental component's IF (the instantaneous heart rate)
[c] = CurveExt_M(abs(Q(tmpm+1:tmpM, :))', .1) ;
c = c + tmpm ;
IF = tfrsqtic1(c) * fs ;
CARDc = c ;

% reconstruct the qq-th cardiac harmonic using the reconstruction formula of SST
[h, ~, ~] = hermf(wlen, 1, 6);
Band = median(tfrsqtic1(c)*fs) * 0.5 ;
[reconHARM] = Recon_sqSTFT_v2(tfrsq1, tfrsqtic1, fs, c, Band, h((wlen+1)/2));