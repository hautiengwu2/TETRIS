% plot the TFR BEFORE n-th shift

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;
M = quantile(abs(tfrsq1(:)), .995) ;
M2 = quantile(abs(tfr1(:)), .999) ;

subplot_tight(2, 2, 1, [0.043 0.061]) ; hold off
imagesc((1:length(x))/fs, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; ylabel('Freq (Hz)') ;
axis([-inf inf 0 2]) ; set(gca, 'fontsize', 18) ;
title(['SST: BEFORE ' num2str(qq) 'th phase shift'])

subplot_tight(2, 2, 2, [0.043 0.061]) ; hold off
imagesc((1:length(x))/fs, tfrtic1*fs, abs(tfr1), [0 M2]) ; axis xy
colormap(1-gray) ; colorbar ;
axis([-inf inf 0 2]) ; set(gca, 'fontsize', 18) ;
title(['STFT: BEFORE ' num2str(qq) 'th phase shift'])

subplot_tight(2, 2, 3, [0.043 0.061]) ; hold off
imagesc((1:length(x))/fs, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; ylabel('Freq (Hz)') ;
hold on ;
plot(Rlocsf/fs, IHR(Rlocsf), 'rx', 'linewidth', 2) ;
axis([-inf inf 0 2]) ; set(gca, 'fontsize', 18) ;

subplot_tight(2, 2, 4, [0.043 0.061]) ; hold off
imagesc((1:length(x))/fs, tfrtic1*fs, abs(tfr1), [0 M2]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ;
hold on ;
plot(Rlocsf/fs, IHR(Rlocsf), 'rx', 'linewidth', 2) ;
axis([-inf inf 0 2]) ; set(gca, 'fontsize', 18) ;

exportgraphics(h1, ['Step' num2str(qq) '-' num2str(sIDX) '.png'],...
    'ContentType', 'vector', 'BackgroundColor','none');