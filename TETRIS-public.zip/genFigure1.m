clear; clc; close all;

addpath('./SST')
addpath('./tool')

warning('off', 'all');
scrsz = get(0,'ScreenSize') ;
initstate(5)

N = 2048 ;
fs = 48 ;

% 1: RIAV, 2: RIFV, 3: RIAV+RIFV
TYPE = 3 ;

%% the instantaneous frequency of the simulated signal
if1 = smooth(cumsum(randn(N,1)) ./ fs, 500, 'loess') ;
if1 = 1.2 + 0.3 * if1 ./ max(abs(if1)) ;
if1 = 1.2 + 0.3 * if1 ./ max(abs(if1)) ;
phi1 = cumsum(if1) / fs ;

if2 = smooth(cumsum(randn(N,1)) ./ fs, 1200, 'loess') ;
if2 = 0.35 + 0.1 * if2 ./ max(abs(if2)) ;
if TYPE == 3
    if2 = 0.4 + 0.1 * if2 ./ max(abs(if2)) ;
end
phi2 = cumsum(if2) / fs ;

% type 1
if TYPE == 1
    RIAV = 1 + 0.2*cos(2*pi*phi2) ;
    x0 = RIAV .* cos(2*pi*phi1) +...
        0.5* RIAV .* cos(2*pi*2*phi1+1) +...
        0.3* RIAV .* cos(2*pi*3*phi1+1.3) +...
        0.1* RIAV .* cos(2*pi*4*phi1+0.3) ;
end

% type 2
if TYPE == 2
    phi3 = phi1 + 0.2*sin(2*pi*phi2) ./ if2 /2/pi;
    x0 = cos(2*pi*phi3) +...
        0.5 .* cos(2*pi*2*phi3 + 1) +...
        0.3 .* cos(2*pi*3*phi3 + 1.3) +...
        0.1 .* cos(2*pi*4*phi3 + 0.3) ;
end


% type 3
if TYPE == 3
    RIAV = 1 + 0.2*cos(2*pi*phi2+0.5) ;
    phi3 = phi1 + 0.1*sin(2*pi*phi2) ./ if2 /2/pi;
    x0 = RIAV .* cos(2*pi*phi3) +...
        0.5 .* RIAV .* cos(2*pi*2*phi3 + 1) +...
        0.2 .* RIAV .* cos(2*pi*3*phi3 + 1.3) +...
        0.05 .* RIAV .* cos(2*pi*4*phi3 + 0.3) ;
end




% explore PS
if 0
    xhat = fft(x0, 3*length(x0)) ;
    xi = fs*(1:length(xhat)/2)/length(xhat) ;
    plot(xi, abs(xhat(2:end/2+1))) ;
    xlim([0 5]) ;
    pause ;
end



Wn = [1.4 2]/(fs/2);
[bbb, aaa] = butter(4, Wn, 'bandpass') ;
time = (1:length(x0))'/fs ;
noise1 = filtfilt(bbb, aaa, randn(size(x0))) ;
noise1 = noise1 .* exp(-(time-10).^2/1.3) ;


Wn = [2.8 3.4]/(fs/2);
[bbb, aaa] = butter(4, Wn, 'bandpass') ;
time = (1:length(x0))'/fs ;
noise2 = filtfilt(bbb, aaa, randn(size(x0))) ;
noise2 = noise2 .* exp(-(time-30).^2/1.3) ;


x = x0 + 10*noise1 + 10*noise2 ;



if TYPE == 3

    Wn = [1.4 5]/(fs/2);
    [bbb, aaa] = butter(4, Wn, 'bandpass') ;
    time = (1:length(x0))'/fs ;
    noise1 = filtfilt(bbb, aaa, randn(size(x0))) ;
    noise1 = noise1 .* exp(-(time-10).^2/3) ;


    Wn = [2.8 7]/(fs/2);
    [bbb, aaa] = butter(4, Wn, 'bandpass') ;
    time = (1:length(x0))'/fs ;
    noise2 = filtfilt(bbb, aaa, randn(size(x0))) ;
    noise2 = noise2 .* exp(-(time-30).^2/3.5) ;


    x = x0 + 2*noise1 + 2*noise2 ;

end

x = x0 ;


freq_resolution = 2e-4;
hop = 10 ;
 



freq_high = 6/fs ;
freq_low = 0 ;

if TYPE < 3
    WINLEN = fs*32+1 ;
else
    WINLEN = fs*40+1 ;
end

[tfr1, tfrtic1, tfrsq1, ~, tfrsqtic1, ~] = ConceFT_sqSTFT_C(x,...
    freq_low, freq_high, 1e-4, hop, WINLEN, 1, 10, 1, 1, 0) ;

[~, ~, tfrsq2, ~, ~, ~] = ConceFT_sqSTFT_C(x.*exp(-1i*2*pi*phi1),...
    freq_low, freq_high, 1e-4, hop, WINLEN, 1, 10, 1, 1, 0) ;

[~, ~, tfrsq3, ~, ~, ~] = ConceFT_sqSTFT_C(x.*exp(-1i*2*pi*2*phi1),...
    freq_low, freq_high, 1e-4, hop, WINLEN, 1, 10, 1, 1, 0) ;

[~, ~, tfrsq4, ~, ~, ~] = ConceFT_sqSTFT_C(x.*exp(-1i*2*pi*3*phi1),...
    freq_low, freq_high, 1e-4, hop, WINLEN, 1, 10, 1, 1, 0) ;

[~, ~, tfrsq5, ~, ~, ~] = ConceFT_sqSTFT_C(x.*exp(-1i*2*pi*4*phi1),...
    freq_low, freq_high, 1e-4, hop, WINLEN, 1, 10, 1, 1, 0) ;

T = (abs(tfrsq1) + abs(tfrsq2) + abs(tfrsq3) + abs(tfrsq4) + abs(tfrsq5)) / 5 ;


%%
h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ; pause(0.1)
M = quantile(abs(tfrsq1(:)), .995) ;
M2 = quantile(abs(tfr1(:)), .999) ;


subplot_tight(3, 4, 1:4, [0.16 0.045]) ;
plot((1:length(x))/fs-4, x, 'k', 'linewidth', 3) ; hold on ;
if TYPE == 1
    plot((1:length(x))/fs-4, 1 + 0.2*cos(2*pi*phi2), 'b--', 'linewidth', 3) ;
end
axis([0 N/fs-8 -inf inf]) ; xlabel('Time (s)') ; set(gca, 'fontsize', 18) ; 
text(0.5, -1.8, '(a)', 'fontsize', 32) ;

subplot_tight(3, 4, 5, [0.043 0.03]) ;
imagesc((1:hop:length(x))/fs-4, tfrtic1*fs, abs(tfr1), [0 M2]) ; axis xy
colormap(1-gray) ; colorbar ;  ylabel('Freq (Hz)') ;
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(b)', 'fontsize', 32) ;

subplot_tight(3, 4, 6, [0.043 0.03]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; 
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(c)', 'fontsize', 32) ;

subplot_tight(3, 4, 7, [0.043 0.03]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
hold on ;
plot((1:length(x))/fs-4, if1, 'r', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1+if2, 'b', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1-if2, 'b', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 2*if1, 'r--', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 2*if1+if2, 'b--', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 2*if1-if2, 'b--', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 3*if1, 'r--', 'linewidth', 1) ;
plot((1:length(x))/fs-4, 3*if1+if2, 'b--', 'linewidth', 1) ;
plot((1:length(x))/fs-4, 3*if1-if2, 'b--', 'linewidth', 1) ;
colormap(1-gray) ; colorbar ;  
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(d)', 'fontsize', 32) ;


subplot_tight(3, 4, 8, [0.043 0.03]) ;
M = quantile(abs(T(:)), .995) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(T), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ;  
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(e)', 'fontsize', 32) ;

subplot_tight(3, 4, 9, [0.043 0.03]) ;
M = quantile(abs(tfrsq2(:)), .995) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq2), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; ylabel('Freq (Hz)') ;
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(f)', 'fontsize', 32) ;

subplot_tight(3, 4, 10, [0.043 0.03]) ;
M = quantile(abs(tfrsq3(:)), .995) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq3), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; 
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(g)', 'fontsize', 32) ;

subplot_tight(3, 4, 11, [0.043 0.03]) ;
M = quantile(abs(tfrsq4(:)), .995) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq4), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; 
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(h)', 'fontsize', 32) ;

subplot_tight(3, 4, 12, [0.043 0.03]) ;
M = quantile(abs(tfrsq5(:)), .995) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq5), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; 
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(i)', 'fontsize', 32) ;

if TYPE == 1
    exportgraphics(h1, 'Figure2.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
end

if TYPE == 2
    exportgraphics(h1, 'Figure2-2.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
end


if TYPE == 3
    exportgraphics(h1, 'Figure3.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
end




%% generate figures for slides

h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ; pause(0.1)
M = quantile(abs(tfrsq1(:)), .995) ;
M2 = quantile(abs(tfr1(:)), .999) ;


subplot_tight(3, 3, 1:3, [0.16 0.045]) ;
plot((1:length(x))/fs-4, x, 'k', 'linewidth', 3) ; hold on ;
if TYPE == 1
    plot((1:length(x))/fs-4, 1 + 0.2*cos(2*pi*phi2), 'b--', 'linewidth', 3) ;
end
axis([0 N/fs-8 -inf inf]) ; xlabel('Time (s)') ; set(gca, 'fontsize', 18) ; 

subplot_tight(3, 3, [4 7], [0.043 0.03]) ;
imagesc((1:hop:length(x))/fs-4, tfrtic1*fs, abs(tfr1), [0 M2]) ; axis xy
colormap(1-gray) ; colorbar ;  ylabel('Freq (Hz)') ;
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 

subplot_tight(3, 3, [5 8], [0.043 0.03]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; 
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 

subplot_tight(3, 3, [6 9], [0.043 0.03]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
hold on ;
plot((1:length(x))/fs-4, if1, 'r', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1+if2, 'b', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1-if2, 'b', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 2*if1, 'r--', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 2*if1+if2, 'b--', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 2*if1-if2, 'b--', 'linewidth', 3) ;
plot((1:length(x))/fs-4, 3*if1, 'r--', 'linewidth', 1) ;
plot((1:length(x))/fs-4, 3*if1+if2, 'b--', 'linewidth', 1) ;
plot((1:length(x))/fs-4, 3*if1-if2, 'b--', 'linewidth', 1) ;
colormap(1-gray) ; colorbar ;  
axis([0 N/fs-8 0 5.5]) ; set(gca, 'fontsize', 18) ; 

exportgraphics(h1, ['Slide1' num2str(TYPE) '.pdf'], 'ContentType', 'vector', 'BackgroundColor','none');




pause;











%% generate Figure 1 simulation

initstate(111)
if1 = smooth(cumsum(randn(N,1)) ./ fs, 500, 'loess') ;
if1 = 1.2 + 0.3 * if1 ./ max(abs(if1)) ;
phi1 = cumsum(if1) / fs ;

if2 = smooth(cumsum(randn(N,1)) ./ fs, 1200, 'loess') ;
if2 = 0.35 + 0.1 * if2 ./ max(abs(if2)) ;
phi2 = cumsum(if2) / fs ;

x = (1 + 0.2*cos(2*pi*phi2)) .* cos(2*pi*phi1) ;


freq_high = 6/fs ;
freq_low = 0 ;
[tfr1, tfrtic1, tfrsq1, ~, tfrsqtic1, ~] = ConceFT_sqSTFT_C(x,...
    freq_low, freq_high, 1e-4, hop, fs*32+1, 1, 10, 1, 1, 0) ;

%
h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*3/4]) ; pause(0.1)
M = quantile(abs(tfrsq1(:)), .995) ;
M2 = quantile(abs(tfr1(:)), .999) ;


subplot_tight(3, 3, 1:3, [0.17 0.045]) ;
plot((1:length(x))/fs-4, x, 'k', 'linewidth', 3) ; hold on ;
plot((1:length(x))/fs-4, 1 + 0.2*cos(2*pi*phi2), 'b--', 'linewidth', 3) ;
axis([0 N/fs-8 -inf inf]) ; xlabel('Time (s)') ; set(gca, 'fontsize', 18) ; 
text(0.3, -1, '(a)', 'fontsize', 32) ;

subplot_tight(3, 3, [4 7], [0.043 0.04]) ;
imagesc((1:hop:length(x))/fs-4, tfrtic1*fs, abs(tfr1), [0 M2]) ; axis xy
colormap(1-gray) ; colorbar ;  ylabel('Freq (Hz)') ; xlabel('Time (s)')
axis([0 N/fs-8 0 3]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(b)', 'fontsize', 32) ;

subplot_tight(3, 3, [5 8], [0.043 0.04]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') 
axis([0 N/fs-8 0 3]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(c)', 'fontsize', 32) ;

subplot_tight(3, 3, [6 9], [0.043 0.04]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
hold on ;
plot((1:length(x))/fs-4, if1, 'r', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1+if2, 'b', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1-if2, 'b', 'linewidth', 3) ;
colormap(1-gray) ; colorbar ; xlabel('Time (s)')
axis([0 N/fs-8 0 3]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(d)', 'fontsize', 32) ;


exportgraphics(h1, 'Figure1.pdf', 'ContentType', 'vector', 'BackgroundColor','none');



h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)*3/4]) ; pause(0.1)
M = quantile(abs(tfrsq1(:)), .995) ;
M2 = quantile(abs(tfr1(:)), .999) ;

subplot_tight(2, 3, 1:3, [0.17 0.045]) ;
plot((1:length(x))/fs-4, x, 'k', 'linewidth', 3) ; hold on ;
plot((1:length(x))/fs-4, 1 + 0.2*cos(2*pi*phi2), 'b--', 'linewidth', 3) ;
axis([0 N/fs-8 -inf inf]) ; xlabel('Time (s)') ; set(gca, 'fontsize', 18) ; 
text(0.3, -1, '(a)', 'fontsize', 32) ;

subplot_tight(2, 3, 4, [0.043 0.04]) ;
imagesc((1:hop:length(x))/fs-4, tfrtic1*fs, abs(tfr1), [0 M2]) ; axis xy
colormap(1-gray) ; colorbar ;  ylabel('Freq (Hz)') ; xlabel('Time (s)')
axis([0 N/fs-8 0 3]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(b)', 'fontsize', 32) ;

subplot_tight(2, 3, 5, [0.043 0.04]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') 
axis([0 N/fs-8 0 3]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(c)', 'fontsize', 32) ;

subplot_tight(2, 3, 6, [0.043 0.04]) ;
imagesc((1:hop:length(x))/fs-4, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
hold on ;
plot((1:length(x))/fs-4, if1, 'r', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1+if2, 'b', 'linewidth', 3) ;
plot((1:length(x))/fs-4, if1-if2, 'b', 'linewidth', 3) ;
colormap(1-gray) ; colorbar ; xlabel('Time (s)')
axis([0 N/fs-8 0 3]) ; set(gca, 'fontsize', 18) ; 
text(1, 0.5, '(d)', 'fontsize', 32) ;


exportgraphics(h1, 'Figure1.pdf', 'ContentType', 'vector', 'BackgroundColor','none');
