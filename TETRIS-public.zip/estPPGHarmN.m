function [CARDc, reconHARM, IF, tfrsq1, tfrsqtic1, tfr1, tfrtic1]...
    = estPPGHarmN(xSHIFT, fs, CARDc, hop)

wlen = round(10*fs)*2+1 ; % 20s window
[tfr1, tfrtic1, tfrsq1, ~, tfrsqtic1, ~] = ConceFT_sqSTFT_C(xSHIFT,...
    0, 0.1, 1e-4, hop, wlen, 1, 6, 1, 1, 0) ;

% correct the curve by running the curve extraction again
QQ = zeros(41, length(xSHIFT)) ;
for oo = 1: length(xSHIFT)
    QQ(:, oo) = tfrsq1(CARDc(oo)-20: CARDc(oo)+20, oo) ;
end
[c] = CurveExt_M(abs(QQ)', .5) ;
c = c + CARDc - 20 - 1 ;
IF = tfrsqtic1(c) * fs ;




% reconstruct the qq-th cardiac harmonic using the reconstruction formula of SST
[h, ~, ~] = hermf(wlen, 1, 6);
Band = median(tfrsqtic1(c)*fs) * 0.5 ;
[reconHARM] = Recon_sqSTFT_v2(tfrsq1, tfrsqtic1, fs, c, Band, h((wlen+1)/2));