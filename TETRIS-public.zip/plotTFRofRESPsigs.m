%% generate TFR of different extracted respiratory signals
wlen = round(45*fs)*2+1;    % 90s window
[~, ~, tfrsqPPGenv, ~, tfrsqtic, ~] = ConceFT_sqSTFT_C(PPGenv - mean(PPGenv),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;

tmp = squeeze(reconAMosc(sIDX, :, 1))' ;
[~, ~, tfrsqRT1, ~, ~, ~] = ConceFT_sqSTFT_C(tmp - mean(tmp),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
tmp = squeeze(reconAMosc(sIDX, :, 2))' ;
[~, ~, tfrsqRT2, ~, ~, ~] = ConceFT_sqSTFT_C(tmp - mean(tmp),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
tmp = squeeze(reconAMosc(sIDX, :, 3))' ;
[~, ~, tfrsqRT3, ~, ~, ~] = ConceFT_sqSTFT_C(tmp - mean(tmp),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
tmp = squeeze(reconAMosc(sIDX, :, 4))' ;
[~, ~, tfrsqRT4, ~, ~, ~] = ConceFT_sqSTFT_C(tmp - mean(tmp),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
tmp = squeeze(reconAMosc(sIDX, :, n_harm+1))' ;
[~, ~, tfrsqRT0, ~, ~, ~] = ConceFT_sqSTFT_C(tmp - mean(tmp),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;

tfrsqesb = (abs(tfrsqRT0) + abs(tfrsqRT1) + abs(tfrsqRT2) ...
    + abs(tfrsqRT3) + abs(tfrsqRT4)) ./ 5 ;

[~, ~, tfrsqPPGresp, ~, ~, ~] = ConceFT_sqSTFT_C(PPGresp - mean(PPGresp),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
[~, ~, tfrsqABD, ~, ~, ~] = ConceFT_sqSTFT_C(abd - mean(abd),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
[~, ~, tfrsqTHO, ~, ~, ~] = ConceFT_sqSTFT_C(tho - mean(tho),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;
[~, ~, tfrsqairflow, ~, ~, ~] = ConceFT_sqSTFT_C(airflow - mean(airflow),...
    0, 1/fs, 1e-4, 10, wlen, 1, 6, 1, 1, 0) ;





%%
h3 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ; pause(0.1)

M = quantile(abs(tfrsqPPGenv(:))/1000, .995) ;
subplot_tight(3, 3, 1, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqPPGenv)/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; ylabel('Freq (Hz)') ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; 
if ~PAPER ; title('PPGenv') ; end
set(gca, 'xtick', []) ; text(15, 0.9, '(a)', 'fontsize', 36) ;

M = quantile(abs(tfrsqRT0(:))/1000, .995) ;
subplot_tight(3, 3, 2, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqRT0)/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; 
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; 
if ~PAPER ; title('H0resp') ; end
set(gca, 'xtick', []) ; set(gca, 'ytick', []) ; text(15, 0.9, '(b)', 'fontsize', 36) ;

M = quantile(abs(tfrsqRT1(:))/1000, .995) ;
subplot_tight(3, 3, 3, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqRT1)/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; 
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; 
if ~PAPER ; title('H1resp') ; end
set(gca, 'xtick', []) ; set(gca, 'ytick', []) ; text(15, 0.9, '(c)', 'fontsize', 36) ;

M = quantile(abs(tfrsqRT2(:))/1000, .995) ;
subplot_tight(3, 3, 4, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqRT2)/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; ylabel('Freq (Hz)') ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; 
if ~PAPER ; title('H2resp') ; end
set(gca, 'xtick', []) ; text(15, 0.9, '(d)', 'fontsize', 36) ;

M = quantile(abs(tfrsqRT3(:))/1000, .995) ;
subplot_tight(3, 3, 5, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqRT3)/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; set(gca, 'xtick', []) ; set(gca, 'ytick', []) ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; text(15, 0.9, '(e)', 'fontsize', 36) ;
if ~PAPER ; title('H3resp') ; end


M = quantile(abs(tfrsqRT4(:))/1000, .995) ;
subplot_tight(3, 3, 6, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqRT4)/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; set(gca, 'xtick', []) ; set(gca, 'ytick', []) ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; text(15, 0.9, '(f)', 'fontsize', 36) ;
if ~PAPER ; title('H4resp') ; end


M = quantile(tfrsqesb(:), .995)/1000 ;
subplot_tight(3, 3, 7, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, tfrsqesb/1000, [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; ylabel('Freq (Hz)') ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; text(15, 0.9, '(g)', 'fontsize', 36) ;
if ~PAPER ; title('ens0-4') ; end

M = quantile(abs(tfrsqairflow(:)), .995) ;
subplot_tight(3, 3, 8, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqairflow), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; set(gca, 'ytick', []) ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; text(15, 0.9, '(h)', 'fontsize', 36) ;
if ~PAPER ; title('airflow') ; end

% M = quantile(abs(tfrsqTHO(:)), .995) ;
% subplot_tight(3, 3, 8, [0.03 0.03]) ;
% imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqTHO), [0 M]) ; axis xy
% colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; 
% axis([-inf inf 0 1]) ; set(gca, 'fontsize', 18) ; title('THO')

M = quantile(abs(tfrsqABD(:)), .995) ;
subplot_tight(3, 3, 9, [0.03 0.03]) ;
imagesc((10:10:length(x))/fs, tfrsqtic*fs, abs(tfrsqABD), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ; set(gca, 'ytick', []) ;
axis([10 190 0 1]) ; set(gca, 'fontsize', 18) ; text(15, 0.9, '(i)', 'fontsize', 36) ;
if ~PAPER ; title('ABD') ; end

exportgraphics(h3, [num2str(rIDX) '_' num2str(sIDX) 'TFRofRESP.pdf'],...
    'ContentType', 'vector', 'BackgroundColor','none');
