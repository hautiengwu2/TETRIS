clear; clc; close all;

addpath('./SST')
addpath('./tool')
addpath('./SAMD')

warning('off', 'all');
scrsz = get(0,'ScreenSize') ;

generateFIGURES = 1 ;

% if the figures are used for the paper
PAPER = 1 ;


% database location
folder = '/Users/hautiengwu/Dropbox/___working tex since 20221228/_WORKING IMU-resp/code/database20251111';
ggg = dir([folder '/*.mat']) ;




% number of harmonics of the cardiac component to extract
% this parameter in practice depends on the sampling rate
n_harm = 4 ;

% parameters for SAMD
% number of harmonics of the AM of the cardiac component
% this parameter in practice depends on the respiratory rate and heart rate
% unless a more sophisticated joint optimization is used
n_am = 2;
% this is the degree of polynomial used in SAMD
K = 2 ;

% segment length
SegLEN = 200 ;

% boundary length to avoid boundary effect
BDRY = 10 ;



% no downsample. Might be slow
hop = 1 ;


for rIDX = 1: length(ggg)

    load([folder '/' ggg(rIDX).name]);



    % ppg = red channel. Other channels later
    ppg_ = database.red.ppg.signal' ;
    fs = double(database.red.ppg.fs) ;

    airflow_ = database.airflow.signal' ;
    airflow_ = resample(airflow_, fs, double(database.airflow.fs));
    abd_ = database.abdomen.signal' ;
    abd_ = resample(abd_, fs, double(database.abdomen.fs));
    tho_ = database.thorax.signal' ;
    tho_ = resample(tho_, fs, double(database.thorax.fs));



    % collect 200 s segment.
    SegNO = floor( (length(ppg_) - SegLEN*fs) ./ (SegLEN*fs - BDRY*fs) ) + 1 ;


    % Design a Butterworth high-pass filter
    % n is the filter order, you can start with 4 for a moderate filter
    Wn = 0.1 / (fs / 2);
    [bbb, aaa] = butter(4, Wn, 'high');

    Wn = 1 / (fs / 2);
    [ddd, ccc] = butter(4, Wn, 'low');

    % decomposed n-th shifted cardiac harmonic
    HarmDecomp = zeros(SegNO, SegLEN*fs, n_harm) ;

    % estimated n-th cardiac harmonic
    HarmEST = zeros(SegNO, SegLEN*fs, n_harm) ;

    % estimated phase of the n-th shifted cardiac harmonic
    phiEST = zeros(SegNO, SegLEN*fs, n_harm) ;

    % PPG BEFORE the n-th shifting
    beforeShiftEST = zeros(SegNO, SegLEN*fs, n_harm) ;

    % PPG BEFORE the n-th shifting
    afterShiftEST = zeros(SegNO, SegLEN*fs, n_harm) ;

    % this is the n-th shifted cardiac harmonic AM
    reconAM = zeros(SegNO, SegLEN*fs, n_harm+1) ;

    % these are 3 components of the n-th shifted cardiac harmonic AM
    reconAMtrend = zeros(SegNO, SegLEN*fs, n_harm+1) ;
    reconAMosc = zeros(SegNO, SegLEN*fs, n_harm+1) ;
    reconAMextra = zeros(SegNO, SegLEN*fs, n_harm+1) ;

    % only the fundamental component of the osc in the n-th shifted cardiac
    % harm AM
    reconAMosc1 = zeros(SegNO, SegLEN*fs, n_harm+1) ;

    % this is estimated IRR from the n-th cardiac harmonic AM
    reconAMIF = zeros(SegNO, SegLEN*fs, n_harm+1) ;

    % random spherical samples
    initstate(1)
    S2P = randn(n_harm+1, 1000) ;
    for jj = 1: 1000
        S2P(:, jj) = S2P(:, jj) ./ norm(S2P(:, jj)) ;
    end

     

    for sIDX = 1: SegNO

        fprintf(['Analyze the ' num2str(sIDX) '-th segment/' num2str(SegNO) '\n']) ;

        START = (sIDX-1) * (SegLEN-BDRY)*fs + 1 ;
        END = min((sIDX-1) * (SegLEN-BDRY)*fs + SegLEN*fs, length(abd_)) ;
        IDX = START: END ;

        % this is the true respiratory signal (abdominal movement). Can consider thoracic
        % movement tho or airflow
        abd = abd_(IDX);
        tho = tho_(IDX);
        airflow = airflow_(IDX) ;

        % get the expiration initiation time of each breathing cycle
        [IRR, RlocsfT, RlocsfA] = getIRR(tho, abd, fs) ;



        % this is PPG signal
        x0 = ppg_(IDX) - mean(ppg_(IDX)) ;
        x = filtfilt(bbb, aaa, x0) ;
        N = length(x) ;

        [IHR, PPGenv, RIAV, RIIV] = gettRIIVRIAV(x, fs) ;



        %% start the new approach to get AM

        xSHIFT = x ;
        TFRQ1 = {} ; TFRQ2 = {} ;

        t11 = tic ;
        if generateFIGURES
            h100 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)/2]) ; pause(0.1)
        end

        for qq = 1: n_harm

            % STEP 1: use SST to get a more accurate cardic phase
            if qq == 1

                % before first shift, apply the traditional PPG-resp via trend
                fprintf('\tRecon the PPG-resp from trend\n')
                [T1, tfrsq0, tfrsqtic0, tfr0, tfrtic0]...
                    = estShiftedPPG(xSHIFT, fs, hop) ;
                tfrsq0 = tfrsq0/1000 ;
                reconAMtrend(sIDX, :, n_harm+1) = T1 ;

                fprintf(['\tRecon the ' num2str(qq) '-th cardiac harm\n'])
                [CARDc, reconHARM, IHR, tfrsq1, tfrsqtic1, tfr1, tfrtic1]...
                    = estPPGHarm1(xSHIFT, fs, IHR, hop) ;
            else
                fprintf(['\tRecon the ' num2str(qq) '-th cardiac harm\n'])
                [CARDc, reconHARM, IHR, tfrsq1, tfrsqtic1, tfr1, tfrtic1]...
                    = estPPGHarmN(xSHIFT, fs, CARDc, hop) ;
            end

            HarmDecomp(sIDX, :, qq) = reconHARM ;

            % get the phase of the qq-th cardiac harmonic
            phiEST(sIDX, :, qq) = unwrap(angle(reconHARM))'/2/pi ;
            clear reconFUND ;

            % save the signal BEFORE shift.
            beforeShiftEST(sIDX, :, qq) = xSHIFT ;


            % shift the signal phase by the cardiac phase to enhance the resp info
            % for the next round.
            % As a result, the fundamental cardiac component becomes the trend,
            % and qq-th harmonic, qq>1, becomes the (qq-1)-th harmonic.

            fprintf(['\tAnalyze the ' num2str(qq) 'th phase shift\n']) ;
            xSHIFT = xSHIFT .* exp(-1i*2*pi*squeeze(phiEST(sIDX, :, qq))') ;

            

            afterShiftEST(sIDX, :, qq) = xSHIFT ;


 


            fprintf(['\tGet TFR of the ' num2str(qq) 'th shifted PPG\n'])
            [T1, tfrsq2, tfrsqtic2, tfr2, tfrtic2]...
                = estShiftedPPG(xSHIFT, fs, hop) ;
            TFRQ1{qq} = tfrsq1/1000 ;
            TFRQ2{qq} = tfrsq2/1000 ;

            if qq == 1
                esbSSTs3 = abs(tfrsq0) + abs(tfrsq2) ;
            else
                esbSSTs3 = esbSSTs3 + abs(tfrsq2) ;
            end

            % trend of the qq-th shift
            reconAMtrend(sIDX, :, qq) = T1 ;
        end



        % middle step -- determine the IRR over 0.1-0.5
        tmpM = ceil(0.5 ./ ((tfrsqtic2(2) - tfrsqtic2(1))*fs)) ;
        tmpm = ceil(0.1 ./ ((tfrsqtic2(2) - tfrsqtic2(1))*fs)) ;
        [c] = CurveExt_M(esbSSTs3(tmpm+1:tmpM, :)', .5) ;
        RESPc = c + tmpm ;

        % do it again to better capture resp freq 0.08 ~ 0.52
        QQ = zeros(11, length(c)) ;
        for oo = 1: length(c)
            QQ(:, oo) = esbSSTs3(RESPc(oo)-5: RESPc(oo)+5, oo) ;
        end
        [c] = CurveExt_M(abs(QQ)', .5) ;
        c = c + RESPc - 5 - 1 ;


        % this is the RIAV0 or RIIV!
        tmp = x - reconAMtrend(sIDX, :, n_harm+1)' ;
        [O1, E1, F1, reconAMfund] = estPPGRESP(tmp, 1000*tfrsq0, tfrsqtic0, c, fs, n_am, K) ;
        reconAM(SegNO, :, n_harm+1) = reconAMtrend(sIDX, :, n_harm+1)' + O1 + E1 ;
        reconAMosc(sIDX, :, n_harm+1) = filtfilt(ddd, ccc, O1) ;
        reconAMosc1(sIDX, :, n_harm+1) = reconAMfund ;
        reconAMextra(sIDX, :, n_harm+1) = E1 ;
        reconAMIF(sIDX, :, n_harm+1) = F1 ;

        clear esbSSTs3 ;

        for qq = 1: n_harm

            tfrsq1 = TFRQ1{qq} ; tfrsq2 = TFRQ2{qq} ;
            fprintf(['\tReconstruct AM of the ' num2str(qq) 'th cardiac harmonic\n'])
            tmp = squeeze(afterShiftEST(sIDX, :, qq))' ;
            [O1, E1, F1, reconAMfund] = estPPGRESP(tmp, tfrsq2, tfrsqtic2, c, fs, n_am, K) ;

            % Collect all reconstructed components
            % oscillation of AM of the qq-th harmonic from the (qq-1)-th phase shift
            reconAMosc(sIDX, :, qq) = filtfilt(ddd, ccc, O1) ;
            reconAMosc1(sIDX, :, qq) = reconAMfund ;
            % extra: very low freq oscillation of the qq-th phase shift
            reconAMextra(sIDX, :, qq) = E1 ;

            % recon resp component of the qq-th phase shift
            reconAM(sIDX, :, qq) = T1 + O1 + E1 ;

            % resp freq of AM of the qq-th phase shift
            reconAMIF(sIDX, :, qq) = F1 ;

            % the recon qq-th cardiac harmonic
            HarmEST(sIDX, :, qq) = 2 * (T1 + O1 + E1)...
                .* cos(2*pi*sum(squeeze(phiEST(sIDX, :, 1:qq)), 2)) ;

            % plot the TFRs determined by SST

            if qq == 1
                esbSST10 = abs(tfrsq1) ;
                esbSST90 = abs(tfrsq2) ;
            elseif qq > 1
                esbSST10 = esbSST10 + abs(tfrsq1) ;
                esbSST90 = esbSST90 + abs(tfrsq2) ;
            end

            if generateFIGURES
                 plotTFRallstep ;
            end

        end % over all harmonics

        toc(t11) ;



        % determine optimal respiratory waveform using rotation via RQI
        xi = fs * (0:SegLEN*fs/2-1) / (SegLEN*fs) ;
        idx = find(xi > 0.1 & xi < 0.4) ;
        xhat = zeros(length(idx), n_harm+1) ;
        for ss = 1: n_harm+1
            tmp = squeeze(reconAMosc(sIDX, :, ss)) ;
            tmp = fft(tmp) ./ norm(tmp) ;
            xhat(:, ss) = tmp(idx) ;
        end

        % xRR = the optimal resp from linear combination of x,y,z
        tmp = max(abs(xhat * S2P), [], 1) ;
        [~, idx] = max(tmp) ;
        PPGresp = squeeze(reconAMosc(sIDX,:, :)) * S2P(:, idx(1)) ;

        if generateFIGURES
            figure(h100)
            exportgraphics(h100, [num2str(rIDX) '_' num2str(sIDX) 'TFR_ALLsteps.pdf'],...
                'ContentType', 'vector', 'BackgroundColor','none');

            plotRESPsigs ;

            close all
        end


        filename = [num2str(rIDX) '-' num2str(sIDX) '-decomp.mat'];
        save(filename, 'reconAMtrend', 'reconAMosc', 'reconAMosc1', 'reconAMextra', 'reconAM',...
            'reconAMIF', 'HarmEST', 'tho', 'abd', 'airflow') ;


    end % over all segments

end % over all recordings


