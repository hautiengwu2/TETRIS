function [T1, tfrsq2, tfrsqtic2, tfr2, tfrtic2]...
    = estShiftedPPG(signal, fs, hop)
% Get the AM oscillation (the key of this work)
% using the reconstruction formula of SST

% get the trend of qq-th shifted PPG
T1 = smooth(real(signal), round(45*fs)*2+1, 'loess');

freq_high = 0.05 ;
freq_low = 0 ;
wlen = round(45*fs)*2+1;    % 90s window
[tfr2, tfrtic2, tfrsq2, ~, tfrsqtic2, ~] = ConceFT_sqSTFT_C(signal - T1,...
    freq_low, freq_high, 1e-4, hop, wlen, 1, 6, 1, 1, 0) ;