function [seg] = getCycles(x, oafHz)

pars.estRF.Tresp_range_breathsMin = [6 20];
%pars step 2
pars.lowCutOff_Hz = 0.05;
%pars step 3 (run if ~= 0)
pars.baselineSpan_nPeaks = 5;
%step 4
pars.volThresholdIn_pMedian = 0.2;
pars.volThresholdEx_pMedian = 0.2;
pars.timeThresholdIn_pMedian = 0.2;
pars.timeThresholdEx_pMedian = 0.2;
[seg,~,~] = cyclesAdvance(oafHz, cumsum(x)', pars) ;


% align detected expiration beginning time
QQ = median(x(seg.begEx)) ;
for jj = 1: length(seg.begEx)
    idx = seg.begEx(jj) - oafHz: seg.begEx(jj) + oafHz ;
    [~, aa] = min(abs(x(idx) - QQ)) ;
    seg.begEx(jj) = seg.begEx(jj) - oafHz - 1 + aa ;
end

% stupid idea when the input is stupid signal
if isempty(seg.begIn) 
    if ~isempty(seg.begEx)
        seg.begIn(1) = seg.begEx(1) - 10 ;
    else
        seg.begIn(1) = round(length(x)/2) ;
        seg.begEx(1) = seg.begIn(1) + 10 ;
    end
end

if isempty(seg.begEx)
    if ~isempty(seg.begIn)
        seg.begEx(1) = seg.begIn(1) + 10 ;
    else
        seg.begIn(1) = round(length(x)/2) ;
        seg.begEx(1) = seg.begIn(1) + 10 ;
    end
end

% correct boundary points
if seg.begIn(1) > seg.begEx(1) ; seg.begIn(1) = [] ; end
if length(seg.begIn) > length(seg.begEx) ; seg.begIn(end) = [] ; end


