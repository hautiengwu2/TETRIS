%% plot various extracted components from the PPG

if 0
h2 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ; pause(0.1)

% ppg
subplot_tight(5, 1, 1, [0.02 0.061]) ;
plot((1:length(x)/2)/fs, x(2501:7500), 'b', 'linewidth', 2) ; hold on ;
plot((1:length(x)/2)/fs, PPGenv(2501:7500), 'r', 'linewidth', 2) ;  
%plot((1:length(x)/2)/fs, real(sum(squeeze(HarmDecomp(sIDX, 2501:7500, :)), 2)), 'r', 'linewidth', 2) ;
%plot((1:length(x)/2)/fs, x(2501:7500)-real(sum(squeeze(HarmDecomp(sIDX, 2501:7500, :)), 2)),...
%    'k', 'linewidth', 2) ;
ylabel('PPG') ; set(gca,'fontsize', 18) ; set(gca, 'xtick', []) ;

% 1st harmonic
subplot_tight(5, 1, 2, [0.02 0.061]) ;
plot((1:length(x)/2)/fs, squeeze(real(HarmDecomp(sIDX, 2501:7500, 1))), 'k', 'linewidth', 2) ;
hold on;
plot((1:length(x)/2)/fs, squeeze(reconAM(sIDX, 2501:7500, 1)), 'r', 'linewidth', 2) ;
ylabel('1H AM') ; set(gca,'fontsize', 18) ; ylim([0 inf])
set(gca, 'xtick', []) ;

% 2nd harmonic
subplot_tight(5, 1, 3, [0.02 0.061]) ;
plot((1:length(x)/2)/fs, squeeze(real(HarmDecomp(sIDX, 2501:7500, 2))), 'k', 'linewidth', 2) ;
hold on;
plot((1:length(x)/2)/fs, squeeze(reconAM(sIDX, 2501:7500, 2)), 'r', 'linewidth', 2) ;
ylabel('2H AM') ; set(gca,'fontsize', 18) ; ylim([0 inf])
set(gca, 'xtick', []) ;

subplot_tight(5, 1, 4, [0.02 0.061]) ;
plot((1:length(x)/2)/fs, squeeze(real(HarmDecomp(sIDX, 2501:7500, 3))), 'k', 'linewidth', 2) ;
hold on;
plot((1:length(x)/2)/fs, squeeze(reconAM(sIDX, 2501:7500, 3)), 'r', 'linewidth', 2) ;
ylabel('3H AM') ; set(gca,'fontsize', 18) ; ylim([0 inf])
set(gca, 'xtick', []) ;

subplot_tight(5, 1, 5, [0.043 0.061]) ;
plot((1:length(x)/2)/fs, squeeze(real(HarmDecomp(sIDX, 2501:7500, 4))), 'k', 'linewidth', 2) ;
hold on;
plot((1:length(x)/2)/fs, squeeze(reconAM(sIDX, 2501:7500, 4)), 'r', 'linewidth', 2) ;
ylabel('4H AM') ; set(gca,'fontsize', 18) ; ylim([0 inf])
xlabel('Time (s)')

exportgraphics(h2, [num2str(rIDX) '_' num2str(sIDX) 'ExtractedHarm.pdf'],...
    'ContentType', 'vector', 'BackgroundColor','none');
end






% shift by BDRY s (to avoid boundary effect)
Rlocsf = RlocsfA(RlocsfA>BDRY*fs & RlocsfA<length(PPGenv)-BDRY*fs) - BDRY*fs ;
abd = abd(BDRY*fs+1: end-BDRY*fs) ;
tho = tho(BDRY*fs+1: end-BDRY*fs) ;

%% plot various extracted respiratory signals

h1 = figure('Position',[1 scrsz(4) scrsz(3)*0.6 scrsz(4)]) ; pause(0.1)


subplot_tight(9, 1, 1, [0.013 0.061]) ; hold off
tmp = x(BDRY*fs+1: end-BDRY*fs)/100 ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
tmp = tmp - mean(tmp) ;
plot((1:length(tmp))/fs, tmp, 'k', 'linewidth', 2) ; hold on ;
tmp = RIIV(BDRY*fs+1: end-BDRY*fs)/100 ;
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ; 
ylabel('PPG') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
axis tight ;  ylim([mmm MMM]) ; 
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(a)', 'fontsize', 20) ; end

subplot_tight(9, 1, 2, [0.013 0.061]) ; hold off
tmp = PPGenv(BDRY*fs+1: end-BDRY*fs)/100 ;
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ;
hold on ; plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
tmp = RIAV(BDRY*fs+1: end-BDRY*fs)/100 ;
plot((1:length(tmp))/fs, tmp, 'm', 'linewidth', 2) ;
ylabel('tRIIV\newlinetRIAV') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = min(mmm, quantile(tmp(50*fs+1:140*fs), .001)*1.1) ; 
MMM = max(MMM, quantile(tmp(50*fs+1:140*fs), .999)*1.1) ; 
axis tight ;  ylim([mmm MMM]) ;  
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(b)', 'fontsize', 20) ; end

subplot_tight(9, 1, 3, [0.013 0.061]) ; hold off
tmp = squeeze(reconAMosc(sIDX, BDRY*fs+1: end-BDRY*fs, n_harm+1))/100 ;
plot((1:length(tmp))/fs, tmp, 'k', 'linewidth', 2) ;
hold on ;
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('RIIV') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ;  
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(c)', 'fontsize', 20) ; end

subplot_tight(9, 1, 4, [0.013 0.061]) ; hold off
tmp = squeeze(reconAMosc(sIDX, BDRY*fs+1: end-BDRY*fs, 1))/100 ;
QQ = quantile(squeeze(abs(tmp)), .998) ./ quantile(abs(abd), .998) ;
plot((1:length(tmp))/fs, QQ * abd, 'color', [.8 .8 .8], 'linewidth', 2) ;
hold on ; 
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ;
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('RIAV1') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ; 
set(gca,'ytick', -8:4:4) ; set(gca, 'yticklabel', -8:4:4) ;
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(d)', 'fontsize', 20) ; end

subplot_tight(9, 1, 5, [0.013 0.061]) ; hold off
tmp = squeeze(reconAMosc(sIDX, BDRY*fs+1: end-BDRY*fs, 2))/100 ;
QQ = quantile(squeeze(abs(tmp)), .998) ./ quantile(abs(abd), .998) ;
plot((1:length(tmp))/fs, QQ * abd, 'color', [.8 .8 .8], 'linewidth', 2) ;
hold on ; 
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ;
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('RIAV2') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ; 
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(e)', 'fontsize', 20) ; end

subplot_tight(9, 1, 6, [0.013 0.061]) ; hold off
tmp = squeeze(reconAMosc(sIDX, BDRY*fs+1: end-BDRY*fs, 3))/100 ;
QQ = quantile(squeeze(abs(tmp)), .998) ./ quantile(abs(abd), .998) ;
plot((1:length(tmp))/fs, QQ * abd, 'color', [.8 .8 .8], 'linewidth', 2) ;
hold on ; 
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ;
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('RIAV3') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ;  
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(f)', 'fontsize', 20) ; end

subplot_tight(9, 1, 7, [0.013 0.061]) ; hold off
tmp = squeeze(reconAMosc(sIDX, BDRY*fs+1: end-BDRY*fs, 4))/100 ;
QQ = quantile(squeeze(abs(tmp)), .998) ./ quantile(abs(abd), .998) ;
plot((1:length(tmp))/fs, QQ * abd, 'color', [.8 .8 .8], 'linewidth', 2) ;
hold on ; 
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ;
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('RIAV4') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ;  
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(g)', 'fontsize', 20) ; end

subplot_tight(9, 1, 8, [0.013 0.061]) ; hold off
tmp = tho ;
plot((1:length(tmp))/fs, tmp, 'b', 'linewidth', 2) ;
hold on ;
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('THO') ; set(gca,'fontsize', 16) ; set(gca, 'xtick', []) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ;  
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(h)', 'fontsize', 20) ; end

subplot_tight(9, 1, 9, [0.02 0.061]) ; hold off
tmp = airflow(BDRY*fs+1: end-BDRY*fs) ;
plot((1:length(tmp))/fs, tmp, 'k', 'linewidth', 2) ;
hold on ; 
plot(Rlocsf/fs, zeros(size(Rlocsf)), 'ro', 'linewidth', 3) ;
ylabel('airflow') ; set(gca,'fontsize', 16) ; xlim([10 190]) ;
mmm = quantile(tmp(50*fs+1:140*fs), .001)*1.1 ; MMM = quantile(tmp(50*fs+1:140*fs), .999)*1.1 ; 
axis tight ;  ylim([mmm MMM]) ;
xlabel('Time (s)')
if PAPER ; xlim([50 140]) ; text(61, mmm*2/3, '(i)', 'fontsize', 20) ; end

exportgraphics(h1, [num2str(rIDX) '_' num2str(sIDX) 'ExtractedRESP.pdf'],...
    'ContentType', 'vector', 'BackgroundColor','none');
