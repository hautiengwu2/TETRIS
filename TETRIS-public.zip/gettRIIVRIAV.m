function [IHR, PPGenv, RIAV, RIIV] = gettRIIVRIAV(x, fs)
% get traditional RIIV and traditional RIAV

Wn = 0.1 / (fs / 2);
[bbb, aaa] = butter(4, Wn, 'high');

Wn = 1 / (fs / 2);
[ddd, ccc] = butter(4, Wn, 'low');



% use peak detection to get preliminary IHR information
[R1, Rs, ~, ~] = PPG_peakdetection(x, fs) ;
R1 = unique(R1) ; Rs = unique(Rs) ;
Vx = [1; (Rs(2:end)+Rs(1:end-1))/2; length(x)] ;
Vy = fs./diff(Rs) ;
Vy = [Vy(1); Vy; Vy(end)] ;
IHR = interp1(Vx, Vy, (1:length(x))', 'pchip', 'extrap') ;

% get upper envelope (or RIIV)
if R1(1) == 1 && R1(end) == length(x)
    Vx = R1 ; Vy = x(R1) ;
elseif R1(1) == 1 && R1(end) < length(x)
    Vx = [R1; length(x)] ;
    Vy = [x(R1); x(R1(end))] ;
elseif R1(1) > 1 && R1(end) == length(x)
    Vx = [1; R1] ;
    Vy = [x(R1(1)); x(R1)] ;
else
    Vx = [1; R1; length(x)] ;
    Vy = [x(R1(1)); x(R1); x(R1(end))] ;
end

RIIV = interp1(Vx, Vy, (1:length(x))', 'pchip', 'extrap') ;
PPGenv = filtfilt(bbb, aaa, RIIV) ;
PPGenv = filtfilt(ddd, ccc, PPGenv) ;

% get lower envelope
[T1, ~, ~, ~] = PPG_peakdetection(-x, fs) ;
if T1(1) == 1 && T1(end) == length(x)
    Vx = T1 ; Vy = x(T1) ;
elseif T1(1) == 1 && T1(end) < length(x)
    Vx = [T1; length(x)] ;
    Vy = [x(T1); x(T1(end))] ;
elseif T1(1) > 1 && T1(end) == length(x)
    Vx = [1; T1] ;
    Vy = [x(T1(1)); x(T1)] ;
else
    Vx = [1; T1; length(x)] ;
    Vy = [x(T1(1)); x(T1); x(T1(end))] ;
end
PPGenvL = interp1(Vx, Vy, (1:length(x))', 'pchip', 'extrap') ;

RIAV0 = RIIV - PPGenvL ;
RIAV0 = filtfilt(bbb, aaa, RIAV0) ;
RIAV = filtfilt(ddd, ccc, RIAV0) ;