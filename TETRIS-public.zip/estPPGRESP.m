function [O1, E1, F1, reconAMfund] = estPPGRESP(signal, tfrsq2, tfrsqtic2, c, fs, n_am, K) ;
% Get the AM oscillation (the key of this work)
% using the reconstruction formula of SST
wlen = round(45*fs)*2+1;    % 90s window


% this is the final/refined estimated resp freq
F1 = tfrsqtic2(c) * fs ;


% reconstruct the fundamental component of the resp in the AM of the
% qq-th shifted PPG
[h, ~, ~] = hermf(wlen, 1, 6) ;
Band = median(tfrsqtic2(c)*fs) * 0.2 ;
[reconAMfund] = Recon_sqSTFT_v2(tfrsq2, tfrsqtic2, fs, c, Band, h((wlen+1)/2)) ;


% apply SAMD to recover the AM of the (qq-1)-th shifted PPG
input2SAMDsignal = real(signal(:)) ;
input2SAMDAM = abs(reconAMfund(:)) ;
input2SAMDphase = phase(reconAMfund(:)) ;

[O1] = SAMD(input2SAMDsignal', input2SAMDAM', input2SAMDphase', n_am, K, 1) ;
O1 = real(O1)' ;


% Extra: finally, get the strange oscillatory component of VERY LOW frequency
% This might come from the detrend step. Need to be refined.
Q = tfrsq2 ;
tmpM = ceil(0.1 ./ ((tfrsqtic2(2) - tfrsqtic2(1))*fs)) ;
tmpm = ceil(0.01 ./ ((tfrsqtic2(2) - tfrsqtic2(1))*fs)) ;
Q(1:tmpm, :) = 0 ;
[c] = CurveExt_M(abs(Q(tmpm+1:tmpM, :))', .1) ;
c = c + tmpm ;

Band = median(tfrsqtic2(c)*fs) * 0.5 ;
[E1] = Recon_sqSTFT_v2(tfrsq2, tfrsqtic2, fs, c, Band, h((wlen+1)/2));
E1 = real(E1)' ;