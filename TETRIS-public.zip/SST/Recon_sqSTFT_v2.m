function [recon] = Recon_sqSTFT_v2(tfrsq, tfrsqtic, Hz, c, Band, coeff) 

% Band = absolute frequency band usually is chosen to be 0.1Hz
% tfrsqtic = in the scale of 1Hz
% c is the extracted curve.

alpha = tfrsqtic(2)-tfrsqtic(1) ;
RR = round(Band/(Hz*alpha)); 


recon = [] ;

C = 2 * alpha / coeff ;

for kk = 1: length(c)
	idx = max(1,c(kk)-RR): min(length(tfrsqtic),c(kk)+RR) ;
	recon(kk) = C * sum(tfrsq(idx,kk),1) ;
end

