function [IRR, RlocsfT, RlocsfA] = getIRR(tho, abd, fs)


[seg] = getCycles(tho', fs) ;
RlocsfT = unique(seg.begEx)' ;
if isscalar(RlocsfT)
    IRR1 = 0.1*ones(size(tho)) ;
else
    Vx = [1; (RlocsfT(2:end)+RlocsfT(1:end-1))/2; length(tho)] ;
    Vy = fs./diff(RlocsfT) ;
    Vy = [Vy(1); Vy; Vy(end)] ;
    IRR1 = interp1(Vx, Vy, (1:length(tho))', 'pchip', 'extrap') ;
end

[seg] = getCycles(abd', fs) ;
RlocsfA = unique(seg.begEx)' ;
if isscalar(RlocsfA)
    IRR2 = 0.1*ones(size(abd)) ;
else
    Vx = [1; (RlocsfA(2:end)+RlocsfA(1:end-1))/2; length(abd)] ;
    Vy = fs./diff(RlocsfA) ;
    Vy = [Vy(1); Vy; Vy(end)] ;
    IRR2 = interp1(Vx, Vy, (1:length(abd))', 'pchip', 'extrap') ;
end

IRR = (IRR1 + IRR2) / 2 ;