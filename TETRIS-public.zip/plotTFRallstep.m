% plot the TFR BEFORE n-th shift
figure(h100) ; pause(0.01)

subplot_tight(2, 5, qq, [0.04 0.03]) ; hold off
M = quantile(abs(tfrsq1(:)), .995) ;
imagesc((1:length(x))/fs, tfrsqtic1*fs, abs(tfrsq1), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; 
axis([5 195 0 2.5]) ; set(gca, 'fontsize', 18) ; set(gca, 'xtick', []) ;
if qq == 1 ; ylabel('Freq (Hz)') ; end
if ~PAPER ; title(['BEFORE ' num2str(qq) 'th shift']) ; end

tmp = squeeze(phiEST(sIDX, :, qq)) ;
tmp = diff(tmp)*fs ;
hold on ;plot((1:length(x)-1)/fs, tmp, 'r', 'linewidth', 3) ;

keyboard

subplot_tight(2, 5, 5+qq, [0.04 0.03]) ; hold off
QQidx = find(tfrsqtic2*fs<0.8) ;
tfrsq2c = tfrsq2(QQidx, :) ;
M = quantile(abs(tfrsq2c(:)), .995) ;
imagesc((1:length(x))/fs, tfrsqtic2(QQidx)*fs, abs(tfrsq2c), [0 M]) ; axis xy
colormap(1-gray) ; colorbar ; xlabel('Time (s)') ;
axis([5 195 0 0.8]) ; set(gca, 'fontsize', 18) ;  
if qq==1 
    ylabel('Freq (Hz)') ; 
    hold on ; plot((1:length(x))/fs, IRR, 'r.', 'linewidth', 2) ;
end
if ~PAPER ; title(['AFTER ' num2str(qq) 'th shift']) ; end


if qq == n_harm
    
    M2 = quantile(abs(esbSST10(:)), .999) ;
    subplot_tight(2, 5, 5, [0.04 0.03]) ; hold off
    imagesc((1:length(x))/fs, tfrsqtic1*fs, abs(esbSST10), [0 M2]) ; axis xy
    colormap(1-gray) ; colorbar ; set(gca, 'xtick', []) ;
    axis([5 195 0 2.5]) ; set(gca, 'fontsize', 18) ;
    if ~PAPER ; title('wesbSST BEFORE') ; end

    % M3 = quantile(abs(esbSST3(:)), .999) ;
    % subplot_tight(3, 4, 10, [0.04 0.03]) ; hold off
    % imagesc((1:length(x))/fs, tfrsqtic1*fs, abs(esbSST3), [0 M3]) ; axis xy
    % colormap(1-gray) ; colorbar ;  
    % if ~PAPER 
    %     hold on ; plot((1:length(x))/fs, IHR, 'r', 'linewidth', 2) ;
    % end
    % axis([-inf inf 0 2.5]) ; set(gca, 'fontsize', 18) ;
    % xlabel('Time (s)') ;
    % if ~PAPER ; title('esb|SST| BEFORE') ; end

    esbSST90 = esbSST90(QQidx, :) ;
    M2 = quantile(abs(esbSST90(:)), .999) ;
    subplot_tight(2, 5, 10, [0.04 0.03]) ; hold off
    imagesc((1:length(x))/fs, tfrsqtic2(QQidx)*fs, abs(esbSST90), [0 M2]) ; axis xy
    colormap(1-gray) ; colorbar ;  
    axis([5 195 0 0.8]) ; set(gca, 'fontsize', 18) ;
    xlabel('Time (s)') ;
    if ~PAPER ; title('wesbSST AFTER') ; end

    % M3 = quantile(abs(esbSSTs3(:)), .999) ;
    % subplot_tight(3, 4, 12, [0.04 0.03]) ; hold off
    % imagesc((1:length(x))/fs, tfrsqtic2*fs, abs(esbSSTs3), [0 M3]) ; axis xy
    % colormap(1-gray) ; colorbar ; 
    % axis([-inf inf 0 1]) ; set(gca, 'fontsize', 18) ;
    % hold on ; plot((1:length(x))/fs, IRR, 'r', 'linewidth', 2) ;
    % if ~PAPER
    %     plot((1:length(x))/fs, F1, 'm', 'linewidth', 2) ;
    % end
    % xlabel('Time (s)') ;
    % if ~PAPER ; title('esb|SST| AFTER') ; end

end


